from setuptools import setup, find_packages

setup(
    name="PyGame Framework",
    version="3.6.9",
    author="lugiadev",
    author_email="natsurblx@gmail.com",
    description="Introducing PyGame Framework, your faithful companion in game development. This framework is tailor-made for Python enthusiasts and built upon the sturdy foundation of PyGame. PyGame Framework offers a comprehensive toolkit designed to simplify game creation, from managing sprites to handling events seamlessly. Whether you're a seasoned developer or just starting out, PyGame Framework provides the support you need to bring your gaming visions to life. With its intuitive interface and powerful features, PyGame Framework is your loyal partner on the journey to crafting captivating gaming experiences. Say hello to smoother development and endless possibilities with PyGame Framework! Special thanks to aleccao194 for their inspiration and contribution to the creation of PyGame Framework.",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
)
